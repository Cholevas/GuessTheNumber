from tkinter import *
import random

win = Tk()
win.title("Color Game")
win.geometry("300x300")


def color():

    global run
    run=0
    global timeleft
    global score

    timeleft = 45

    score = 0

    ruleslbl = Label(win, text="Try to guess the color of the text!")
    ruleslbl.grid(column=1, row=1)
    lbl = Label(win, text="Press Enter to Start!")
    lbl.grid(column=1, row=2)
    timelbl = Label(win, text="Time Left: " + str(timeleft))
    timelbl.grid(column=1, row=3)

    colorlbl = Label(win, font=("Times", 50), text="color")
    colorlbl.grid(column=1, row=4)

    txt = Entry(win,width=30)
    txt.grid(column=1, row=5)

    pointslbl = Label(win, text=str(score))
    pointslbl.grid(column=1,columnspan=3, row=6)

    colors = ["red", "blue", "black", "cyan", "yellow", "orange", "purple", "brown", "pink", "lime"]
    def playagain():
        global btn10
        global btn11
        btn10.destroy()
        btn11.destroy()
        pointslbl.destroy()
        color()
    def finish():
        global btn10
        global btn11
        global score
        txt.destroy()
        ruleslbl.destroy()
        lbl.destroy()
        timelbl.destroy()
        colorlbl.destroy()
        pointslbl.configure(text='Your score is '+str(score))
        btn10=Button(win,text="Exit",command=lambda:win.destroy())
        btn10.grid(column=0,row=10)
        btn11=Button(win,text="Play Again",command=playagain)
        btn11.grid(column=2,row=10)




    def countdown():
        global timeleft
        global score
        timeleft = int(timeleft) - 1
        timelbl.config(text="Time Left: " + str(timeleft))
        timelbl.after(1000, countdown)
        if (timeleft < 1):
            finish()

    def Start(*args):
        global run
        if run == 0:
            timelbl.after(1000, countdown)
            run=1
        else:
            colorshuffle()

    def colorshuffle(*args):
        global score
        global text
        text = txt.get()
        if text.upper() == colors[1].upper():
            score = score + 1
            pointslbl.config(text=str(score))
        txt.delete(0, 'end')
        random.shuffle(colors)
        colorlbl.config(fg=str(colors[1]), text=str(colors[0]))

    win.bind("<Return>", Start)
color()
win.mainloop()

